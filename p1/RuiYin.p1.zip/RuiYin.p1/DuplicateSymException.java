/**
 * @author Rui Yin 
 * @date 2019-01-28 13:33
 */
public class DuplicateSymException extends Exception{
}

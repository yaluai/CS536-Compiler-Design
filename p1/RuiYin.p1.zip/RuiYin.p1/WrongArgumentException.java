/**
 * @author Rui Yin 
 * @date 2019-01-28 13:33
 */
public class WrongArgumentException extends Exception{
    public WrongArgumentException(String message) {
        super(message);
    }
}
